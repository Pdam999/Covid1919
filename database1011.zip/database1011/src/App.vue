<template>
  <v-app>
    <v-app-bar app color="suscess" dark>
      <div class="d-flex align-center">
        <v-img
          alt="Vuetify Logo"
          class="shrink mr-2"
          contain
          src="https://exta.co.th/wp-content/uploads/2021/08/covid-19.png"
          transition="scale-transition"
          width="55"
        />
      </div>

      <v-spacer></v-spacer>
      <v-btn to="/" text>
        <span class="mr-2">Home</span>
      </v-btn>
      <v-btn to="/register" text>
        <span class="mr-2">register</span>
        <v-icon dark> mdi-plus </v-icon>
      </v-btn>
    </v-app-bar>

    <v-main>
      <router-view />
    </v-main>
  </v-app>
</template>

<script>
export default {
  name: "App",

  data: () => ({
    //
  }),
};
</script>
