// Initialize Cloud Firestore through Firebase
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
const firebaseApp = initializeApp({
  apiKey: "AIzaSyBpD9kU7EZmLiIyYZ6ultbE97TnNqNjx6c",
  authDomain: "blankkueiei.firebaseapp.com",
  projectId: "blankkueiei",
  storageBucket: "blankkueiei.appspot.com",
  messagingSenderId: "480277014046",
  appId: "1:480277014046:web:ec8c4bfba7d11ef049700f",
  measurementId: "G-PLQCFPSYDR",
});

const db = getFirestore(firebaseApp);
export default db;
